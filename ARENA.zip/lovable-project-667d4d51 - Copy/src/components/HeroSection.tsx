import heroBg from '@/assets/hero-bg-modern.jpg';

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-1000"
        style={{ backgroundImage: `url(${heroBg})` }}
      />

      {/* Animated Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background/80 to-transparent animate-gradient" />

      {/* Floating Geometric Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Large Ring */}
        <div 
          className="absolute top-1/4 right-1/4 w-96 h-96 border border-border/20 rounded-full animate-rotate-slow"
          style={{ animationDuration: '30s' }}
        />
        
        {/* Medium Ring */}
        <div 
          className="absolute bottom-1/3 left-1/4 w-64 h-64 border border-border/10 rounded-full animate-rotate-slow"
          style={{ animationDuration: '25s', animationDirection: 'reverse' }}
        />

        {/* Floating Dots */}
        <div className="absolute top-1/3 left-1/5 w-2 h-2 bg-foreground/20 rounded-full animate-float-slow" />
        <div className="absolute top-2/3 right-1/4 w-3 h-3 bg-foreground/10 rounded-full animate-float-reverse" />
        <div className="absolute bottom-1/4 left-1/3 w-1.5 h-1.5 bg-foreground/30 rounded-full animate-float" />

        {/* Glow Effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-foreground/5 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 pt-20">
        <div className="max-w-5xl mx-auto text-center">
          {/* Badge */}
          <div className="animate-reveal-up delay-100">
            <span className="section-label animate-glow-pulse">Roblox Game Studio</span>
          </div>

          {/* Main Title */}
          <h1 className="section-title mb-8">
            <span className="block animate-reveal-up delay-200">New Era of</span>
            <span className="block text-muted-foreground animate-reveal-up delay-300">
              Roblox Games
            </span>
          </h1>

          {/* Animated Line */}
          <div className="w-24 h-px bg-foreground/30 mx-auto mb-8 animate-line-grow delay-400" />

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-12 font-body leading-relaxed animate-fade-blur delay-500">
            Arena is a game development studio crafting the next generation of 
            immersive Roblox experiences. Something big is coming.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#games" className="btn-primary animate-reveal-up delay-600">
              See What's Coming
            </a>
            <a href="#about" className="btn-outline animate-reveal-up delay-700">
              Learn More
            </a>
          </div>
        </div>
      </div>

    </section>
  );
};

export default HeroSection;
