interface GameCardProps {
  title: string;
  genre: string;
  image: string;
  delay?: number;
}

const GameCard = ({ title, genre, image, delay = 0 }: GameCardProps) => {
  return (
    <div
      className="game-card group animate-reveal-scale hover-lift"
      style={{ animationDelay: `${delay}s` }}
    >
      {/* Image */}
      <div className="relative aspect-[4/5] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="game-card-image w-full h-full object-cover transition-all duration-1000"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-60" />
        
        {/* Hover Overlay */}
        <div className="game-card-overlay absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/20 opacity-0 transition-all duration-700" />
        
        {/* Shine Effect */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
          <div 
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"
          />
        </div>
        
        {/* Hover Content */}
        <div className="game-card-content absolute bottom-0 left-0 right-0 p-8 translate-y-8 opacity-0 transition-all duration-700">
          <p className="font-display text-xs uppercase tracking-widest text-muted-foreground mb-3">
            {genre}
          </p>
          <h3 className="font-display text-3xl font-bold uppercase text-foreground mb-4">
            {title}
          </h3>
          <div className="flex items-center gap-2 text-foreground font-display text-sm uppercase tracking-wider group/link cursor-pointer">
            <span>Explore</span>
            <svg 
              className="w-4 h-4 transition-transform duration-300 group-hover/link:translate-x-2" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </div>
        </div>

        {/* Corner Accent */}
        <div className="absolute top-0 right-0 w-20 h-20 opacity-0 group-hover:opacity-100 transition-all duration-700">
          <div className="absolute top-4 right-4 w-8 h-px bg-foreground/50 transition-all duration-500 group-hover:w-12" />
          <div className="absolute top-4 right-4 w-px h-8 bg-foreground/50 transition-all duration-500 group-hover:h-12" />
        </div>
      </div>

      {/* Static Content Below */}
      <div className="p-6 transition-all duration-500 group-hover:opacity-0 group-hover:-translate-y-4">
        <p className="font-display text-xs uppercase tracking-widest text-muted-foreground mb-1">
          {genre}
        </p>
        <h3 className="font-display text-lg font-bold uppercase text-foreground">
          {title}
        </h3>
      </div>
    </div>
  );
};

export default GameCard;
