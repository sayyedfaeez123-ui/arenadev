import { useEffect, useRef, useState } from 'react';

const stats = [
  { value: 7, suffix: '', label: 'Members' },
  { value: 0, suffix: '', label: 'Players' },
  { value: 0, suffix: '', label: 'Awards' },
];

const AnimatedNumber = ({ value, suffix }: { value: number; suffix: string }) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;
    
    if (value === 0) {
      setCount(0);
      return;
    }

    const duration = 2000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [isVisible, value]);

  return (
    <div ref={ref} className="stat-value">
      {count}{suffix}
    </div>
  );
};

const AboutSection = () => {
  return (
    <section id="about" className="py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-foreground/[0.02] rounded-full blur-3xl" />
        <div className="absolute top-20 right-20 w-2 h-2 bg-foreground/20 rounded-full animate-float" />
        <div className="absolute bottom-32 left-32 w-3 h-3 bg-foreground/10 rounded-full animate-float-reverse" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          {/* Content */}
          <div>
            <span className="section-label animate-reveal-up">About Us</span>
            <h2 className="section-title mb-4">
              <span className="block animate-reveal-up delay-100">Built For</span>
              <span className="block text-muted-foreground animate-reveal-up delay-200">Roblox</span>
            </h2>
            <div className="w-16 h-px bg-foreground/30 mb-8 animate-line-grow delay-300" />
            
            <div className="space-y-6 text-muted-foreground text-lg leading-relaxed">
              <p className="animate-fade-blur delay-400">
                Arena was founded in 2025 with a singular vision: to bring a new era 
                of gaming experiences to the Roblox platform.
              </p>
              <p className="animate-fade-blur delay-500">
                Our passionate team of 7 developers and creators are working tirelessly 
                to craft something truly special. We believe in quality over quantity, 
                and we're committed to delivering games that players will love.
              </p>
              <p className="animate-fade-blur delay-600">
                This is just the beginning. Join us on this journey.
              </p>
            </div>

            <div className="mt-10 flex flex-wrap gap-4 animate-reveal-up delay-700">
              <a href="#careers" className="btn-primary">
                Join Our Team
              </a>
              <a href="#contact" className="btn-outline">
                Stay Updated
              </a>
            </div>
          </div>

          {/* Stats */}
          <div className="relative">
            {/* Decorative Ring */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-80 h-80 border border-border/10 rounded-full animate-rotate-slow" style={{ animationDuration: '40s' }} />
            </div>
            
            <div className="grid grid-cols-3 gap-8 relative z-10">
              {stats.map((stat, index) => (
                <div
                  key={stat.label}
                  className="stat-item animate-reveal-scale"
                  style={{ animationDelay: `${0.3 + index * 0.15}s` }}
                >
                  <AnimatedNumber value={stat.value} suffix={stat.suffix} />
                  <p className="stat-label">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Founded Badge */}
            <div className="text-center mt-12 animate-reveal-up delay-700">
              <div className="inline-flex flex-col items-center px-8 py-4 border border-border rounded-2xl bg-card/50">
                <span className="font-display text-3xl font-black text-foreground">2025</span>
                <span className="text-xs uppercase tracking-widest text-muted-foreground font-display">Founded</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
