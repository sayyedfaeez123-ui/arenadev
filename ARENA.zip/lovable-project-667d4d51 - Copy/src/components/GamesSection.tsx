import gamePlaceholder1 from '@/assets/game-placeholder-1.jpg';

const GamesSection = () => {
  return (
    <section id="games" className="py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute top-1/2 -right-32 w-64 h-64 border border-border/10 rounded-full animate-rotate-slow" style={{ animationDuration: '40s' }} />
        <div className="absolute bottom-1/4 -left-16 w-32 h-32 border border-border/5 rounded-full animate-rotate-slow" style={{ animationDuration: '30s', animationDirection: 'reverse' }} />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="section-label animate-reveal-up">Coming Soon</span>
          <h2 className="section-title animate-reveal-up delay-100">
            Our Games
          </h2>
          <div className="w-16 h-px bg-foreground/30 mx-auto mt-6 animate-line-grow delay-200" />
        </div>

        {/* Single Game Card - Locked/Under Development */}
        <div className="max-w-md mx-auto animate-reveal-scale delay-300">
          <div className="game-card group relative">
            {/* Image */}
            <div className="relative aspect-[4/5] overflow-hidden">
              <img
                src={gamePlaceholder1}
                alt="Coming Soon"
                className="game-card-image w-full h-full object-cover transition-all duration-1000 filter grayscale"
              />
              
              {/* Dark Overlay */}
              <div className="absolute inset-0 bg-background/70" />
              
              {/* Lock Icon & Text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                {/* Lock Icon */}
                <div className="w-20 h-20 border-2 border-foreground/30 rounded-full flex items-center justify-center mb-6 animate-glow-pulse">
                  <svg 
                    className="w-10 h-10 text-foreground/50" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={1.5} 
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" 
                    />
                  </svg>
                </div>
                
                {/* Status Text */}
                <p className="font-display text-xs uppercase tracking-widest text-muted-foreground mb-2">
                  Roblox Game
                </p>
                <h3 className="font-display text-2xl md:text-3xl font-bold uppercase text-foreground mb-4 text-center px-4">
                  Under Development
                </h3>
                <p className="text-muted-foreground text-center max-w-xs px-4">
                  Our first game is currently in development. Stay tuned for updates.
                </p>

                {/* Progress Indicator */}
                <div className="mt-8 w-48">
                  <div className="flex justify-between text-xs text-muted-foreground mb-2 font-display uppercase tracking-wider">
                    <span>Progress</span>
                    <span>Building...</span>
                  </div>
                  <div className="h-1 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full w-1/4 bg-foreground/50 rounded-full animate-pulse" />
                  </div>
                </div>
              </div>

              {/* Corner Accents */}
              <div className="absolute top-4 left-4 w-8 h-8">
                <div className="absolute top-0 left-0 w-4 h-px bg-foreground/30" />
                <div className="absolute top-0 left-0 w-px h-4 bg-foreground/30" />
              </div>
              <div className="absolute top-4 right-4 w-8 h-8">
                <div className="absolute top-0 right-0 w-4 h-px bg-foreground/30" />
                <div className="absolute top-0 right-0 w-px h-4 bg-foreground/30" />
              </div>
              <div className="absolute bottom-4 left-4 w-8 h-8">
                <div className="absolute bottom-0 left-0 w-4 h-px bg-foreground/30" />
                <div className="absolute bottom-0 left-0 w-px h-4 bg-foreground/30" />
              </div>
              <div className="absolute bottom-4 right-4 w-8 h-8">
                <div className="absolute bottom-0 right-0 w-4 h-px bg-foreground/30" />
                <div className="absolute bottom-0 right-0 w-px h-4 bg-foreground/30" />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Text */}
        <div className="text-center mt-16 animate-reveal-up delay-500">
          <p className="text-muted-foreground text-lg mb-2">Our 1st game is on the way</p>
          <p className="text-foreground font-display uppercase tracking-wider">Something epic is coming to Roblox</p>
        </div>
      </div>
    </section>
  );
};

export default GamesSection;
